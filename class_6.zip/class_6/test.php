<?php
include 'config.php';


// $statement = $pdo->prepare("INSERT INTO students(name,email) VALUES(:name,:email)");
// $statement->bindParam(':name', $name);
// $statement->bindParam(':email', $email);
// $name = 'peter';
// $email = 'peter@gmail.com';
// $statement->execute();


// $statement = $pdo->prepare("INSERT INTO students(name,email) VALUES(?,?)");
// $statement->execute(['Smith','smith@gmail.com']);


// $statement = $pdo->prepare("UPDATE students SET name=?,email=? WHERE id=?");
// $statement->execute(['Mister devid','devid@gmail.com',23]);


// $statement = $pdo->prepare("DELETE FROM students");
// $statement->execute();

$statement = $pdo->prepare("DELETE FROM students WHERE id=?");
$statement->execute([31]);