<?php 
// if($a === null){
//     echo "variable 'a' is set.";
// }
// else{
//     echo "Variable 'a' is not set";
// }

// Date time
// echo date('y-F-d l h:i:s A');

// $dt1 = "2023-08-09 15:30:00";
// $ts1 = strtotime($dt1);
// echo date('d/m/y h:i:s-A',$ts1);



// date_default_timezone_set('Asia/Dhaka');
// $purchase_date = date('y-m-d');
// $add_days = 30;
// $expire_date = date('y-m-d', strtotime("$add_days days",strtotime($purchase_date)));
// echo $expire_date;


// $timezone = new DateTimeZone('Asia/Dhaka');
// echo $timezone->getName() . "\n";
// $dt = new DateTime('now',$timezone);
// echo $dt->format('Y-m-d H:i:s');

// $date1 = "2023-08-09";
// $date2 = "2023-12-09";
// $ts1 = strtotime($date1);
// $ts2 = strtotime($date2);
// $diff = ($ts2 - $ts1)/(60*60*24);
// echo $diff;

// $a = 'Wednesday';
// $b = strtotime('next '.$a);
// echo date('y-m-d', $b);

