<?php 
include 'config.php';

$statement = $pdo->prepare("DELETE FROM students WHERE id=?");
$statement->execute([$_REQUEST['id']]);
$result = $statement->fetch(PDO::FETCH_ASSOC);

// Rediresction
header('Location: index.php');
exit;